import { useState } from "react";
import { useSettingsStore, type BankAccount } from "../stores/useSettingsStore";
import { SectionHeader, Button, TextInput, Textarea, ConfirmDialog, Modal } from "../components/ui";
import { Save, Plus, Trash2, Pencil, Landmark, Building2, FileText } from "lucide-react";

export default function SettingsPage() {
  const { company, banks, invoice, updateCompany, updateInvoiceSettings, addBank, updateBank, deleteBank } = useSettingsStore();

  // Company Local State
  const [cForm, setCForm] = useState(company);
  const [invForm, setInvForm] = useState(invoice);

  // Bank Form Local State
  const [showBankForm, setShowBankForm] = useState(false);
  const [editingBankId, setEditingBankId] = useState<string | null>(null);
  const [bankForm, setBankForm] = useState<Omit<BankAccount, "id">>({ bankName: "", accountNumber: "", accountName: "" });
  const [delBank, setDelBank] = useState<string | null>(null);

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    updateCompany(cForm);
    updateInvoiceSettings(invForm);
    alert("Pengaturan berhasil disimpan.");
  };

  const handleSaveBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingBankId) {
      updateBank(editingBankId, bankForm);
    } else {
      addBank(bankForm);
    }
    setShowBankForm(false);
  };

  const openAddBank = () => {
    setBankForm({ bankName: "", accountNumber: "", accountName: "" });
    setEditingBankId(null);
    setShowBankForm(true);
  };

  const openEditBank = (b: BankAccount) => {
    setBankForm({ bankName: b.bankName, accountNumber: b.accountNumber, accountName: b.accountName });
    setEditingBankId(b.id);
    setShowBankForm(true);
  };

  return (
    <div className="space-y-6">
      <SectionHeader title="Pengaturan Sistem" description="Kelola Kop Surat, Nomor Rekening, dan Ketentuan Invoice" />

      <form onSubmit={handleSaveCompany} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          
          {/* Company Settings */}
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-4">
            <div className="flex items-center gap-2 mb-4 border-b pb-2">
              <Building2 className="w-5 h-5 text-gray-500" />
              <h3 className="font-bold text-lg text-gray-900">Data Perusahaan (Kop Surat)</h3>
            </div>
            
            <TextInput label="Nama Perusahaan" required value={cForm.name} onChange={e => setCForm({ ...cForm, name: e.target.value })} />
            <TextInput label="Tagline / Slogan" value={cForm.tagline} onChange={e => setCForm({ ...cForm, tagline: e.target.value })} />
            <TextInput label="Alamat (Baris 1)" value={cForm.addressLine1} onChange={e => setCForm({ ...cForm, addressLine1: e.target.value })} />
            <TextInput label="Alamat (Baris 2)" value={cForm.addressLine2} onChange={e => setCForm({ ...cForm, addressLine2: e.target.value })} />
            
            <div className="grid grid-cols-2 gap-4">
              <TextInput label="Nomor Telepon" value={cForm.phone} onChange={e => setCForm({ ...cForm, phone: e.target.value })} />
              <TextInput label="Nomor Fax" value={cForm.fax} onChange={e => setCForm({ ...cForm, fax: e.target.value })} />
            </div>

            <TextInput label="URL Logo (Opsional)" placeholder="https://..." value={cForm.logoUrl || ""} onChange={e => setCForm({ ...cForm, logoUrl: e.target.value })} />
            {cForm.logoUrl && (
              <div className="mt-2 p-2 border rounded bg-gray-50 w-fit">
                <img src={cForm.logoUrl} alt="Logo Preview" className="h-12 object-contain" />
              </div>
            )}
          </div>

          {/* Invoice Settings */}
          <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm space-y-4">
            <div className="flex items-center gap-2 mb-4 border-b pb-2">
              <FileText className="w-5 h-5 text-gray-500" />
              <h3 className="font-bold text-lg text-gray-900">Ketentuan Invoice & TTD</h3>
            </div>

            <Textarea label="Remarks / Catatan Kaki" rows={4} value={invForm.remarks} onChange={e => setInvForm({ ...invForm, remarks: e.target.value })} />
            
            <div className="grid grid-cols-2 gap-4">
              <TextInput label="Nama Manager (Opsional)" value={invForm.managerName} onChange={e => setInvForm({ ...invForm, managerName: e.target.value })} />
              <TextInput label="Jabatan Penandatangan" required value={invForm.managerTitle} onChange={e => setInvForm({ ...invForm, managerTitle: e.target.value })} />
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <Button type="submit" leftIcon={Save}>Simpan Pengaturan</Button>
        </div>
      </form>

      {/* Bank Accounts Section */}
      <div className="bg-white p-6 rounded-2xl border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between mb-4 border-b pb-2">
          <div className="flex items-center gap-2">
            <Landmark className="w-5 h-5 text-gray-500" />
            <h3 className="font-bold text-lg text-gray-900">Rekening Bank Perusahaan</h3>
          </div>
          <Button size="sm" variant="outline" leftIcon={Plus} onClick={openAddBank}>Tambah Rekening</Button>
        </div>

        {banks.length === 0 ? (
          <p className="text-sm text-gray-500 italic py-4">Belum ada rekening bank yang ditambahkan.</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {banks.map((b) => (
              <div key={b.id} className="p-4 rounded-xl border border-gray-200 bg-gray-50 relative group">
                <div className="absolute top-2 right-2 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button onClick={() => openEditBank(b)} className="p-1.5 text-gray-400 hover:text-blue-600 rounded-md hover:bg-white shadow-sm"><Pencil className="w-3.5 h-3.5" /></button>
                  <button onClick={() => setDelBank(b.id)} className="p-1.5 text-gray-400 hover:text-red-500 rounded-md hover:bg-white shadow-sm"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
                <p className="font-bold text-gray-900">{b.bankName}</p>
                <p className="font-mono text-sm text-blue-600 mt-1">{b.accountNumber}</p>
                <p className="text-xs text-gray-500 mt-1 uppercase">A.N. {b.accountName}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bank Form Modal */}
      <Modal open={showBankForm} onClose={() => setShowBankForm(false)} title={editingBankId ? "Edit Rekening Bank" : "Tambah Rekening Bank"} size="sm">
        <form id="bank-form" onSubmit={handleSaveBank} className="space-y-4">
          <TextInput label="Nama Bank" required placeholder="Contoh: BCA" value={bankForm.bankName} onChange={e => setBankForm({ ...bankForm, bankName: e.target.value })} />
          <TextInput label="Nomor Rekening" required placeholder="Contoh: 1234567890" value={bankForm.accountNumber} onChange={e => setBankForm({ ...bankForm, accountNumber: e.target.value })} />
          <TextInput label="Atas Nama" required placeholder="Contoh: PT. ABC" value={bankForm.accountName} onChange={e => setBankForm({ ...bankForm, accountName: e.target.value })} />
        </form>
        <div className="flex justify-end gap-3 mt-6">
          <Button variant="outline" onClick={() => setShowBankForm(false)}>Batal</Button>
          <Button type="submit" form="bank-form">Simpan</Button>
        </div>
      </Modal>

      <ConfirmDialog open={!!delBank} onClose={() => setDelBank(null)} title="Hapus Rekening?" 
        onConfirm={() => { if (delBank) deleteBank(delBank); setDelBank(null); }} />
    </div>
  );
}
