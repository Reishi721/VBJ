import { Package, ArrowUpToLine, ArrowDownToLine, Wrench, Wallet, AlertOctagon } from "lucide-react";
import { StatsCard } from "../components/ui";
import AssetStatusChart from "../components/dashboard/AssetStatusChart";
import RevenueChart from "../components/dashboard/RevenueChart";
import RecentActivity from "../components/dashboard/RecentActivity";
import DueTodayWidget from "../components/dashboard/DueTodayWidget";

export default function Dashboard() {
  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <StatsCard 
          title="Total Aset" 
          value="2,250" 
          icon={Package} 
          description="Unit tercatat"
          gradientClass="gradient-primary"
          iconBg="bg-blue-50"
        />
        <StatsCard 
          title="Unit Disewa" 
          value="850" 
          icon={ArrowUpToLine} 
          trend={{ value: 12, isPositive: true }}
          description="Bulan ini"
          gradientClass="gradient-purple"
          iconBg="bg-purple-50"
          iconColor="text-purple-600"
        />
        <StatsCard 
          title="Tersedia" 
          value="1,250" 
          icon={ArrowDownToLine} 
          description="Siap disewa"
          gradientClass="gradient-success"
          iconBg="bg-emerald-50"
          iconColor="text-emerald-600"
        />
        <StatsCard 
          title="Perawatan" 
          value="120" 
          icon={Wrench} 
          trend={{ value: 5, isPositive: false }}
          description="Perlu perbaikan"
          gradientClass="gradient-warning"
          iconBg="bg-amber-50"
          iconColor="text-amber-500"
        />
        <StatsCard 
          title="Pendapatan" 
          value="Rp 95Jt" 
          icon={Wallet} 
          trend={{ value: 8.5, isPositive: true }}
          description="Bulan ini"
          gradientClass="gradient-cyan"
          iconBg="bg-cyan-50"
          iconColor="text-cyan-600"
        />
        <StatsCard 
          title="Tunggakan" 
          value="Rp 12.5Jt" 
          icon={AlertOctagon} 
          trend={{ value: 2.1, isPositive: false }}
          description="Piutang"
          gradientClass="gradient-danger"
          iconBg="bg-red-50"
          iconColor="text-red-500"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <AssetStatusChart />
        <RevenueChart />
      </div>

      {/* Bottom */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <RecentActivity />
        <DueTodayWidget />
      </div>
    </div>
  );
}
