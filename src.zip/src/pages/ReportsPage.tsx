import { useMemo, useState, useRef } from "react";
import { useInvoiceStore } from "../stores/useInvoiceStore";
import { useCustomerStore } from "../stores/useCustomerStore";
import { BarChart3, Printer, Search } from "lucide-react";
import { Button, SearchBar, SectionHeader } from "../components/ui";
import { formatRupiah } from "../components/invoice/InvoiceHelpers";
import ReceivablesPrintLayout from "../components/reports/ReceivablesPrintLayout";

interface ReceivablesGroup {
  key: string;
  customerId: string;
  customerName: string;
  projectId: string;
  projectName: string;
  totalInvoice: number;
  totalPaid: number;
  totalRemaining: number;
  invoiceCount: number;
}

export default function ReportsPage() {
  const { invoices } = useInvoiceStore();
  const [search, setSearch] = useState("");
  const printRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  const receivables = useMemo(() => {
    const groups = new Map<string, ReceivablesGroup>();

    invoices.forEach((inv) => {
      // Ignore draft or cancelled invoices for receivables
      if (inv.status === "draft" || inv.status === "cancelled") return;

      const pId = inv.projectId || "";
      const key = `${inv.customerId}-${pId}`;

      if (!groups.has(key)) {
        groups.set(key, {
          key,
          customerId: inv.customerId,
          customerName: inv.customerName,
          projectId: pId,
          projectName: inv.projectName || "Tanpa Proyek",
          totalInvoice: 0,
          totalPaid: 0,
          totalRemaining: 0,
          invoiceCount: 0,
        });
      }

      const g = groups.get(key)!;
      g.totalInvoice += inv.total;
      g.totalPaid += inv.paidAmount;
      g.totalRemaining += inv.remainingAmount;
      g.invoiceCount += 1;
    });

    return Array.from(groups.values()).filter(
      (g) =>
        g.customerName.toLowerCase().includes(search.toLowerCase()) ||
        g.projectName.toLowerCase().includes(search.toLowerCase())
    );
  }, [invoices, search]);

  const grandTotalRemaining = receivables.reduce((sum, g) => sum + g.totalRemaining, 0);
  const grandTotalInvoice = receivables.reduce((sum, g) => sum + g.totalInvoice, 0);

  return (
    <div className="space-y-6 print:hidden">
      <SectionHeader
        title="Laporan Keuangan"
        description="Ringkasan piutang per pelanggan dan proyek"
        action={
          <Button leftIcon={Printer} onClick={handlePrint} disabled={receivables.length === 0}>
            Cetak Laporan Piutang
          </Button>
        }
      />

      <div className="max-w-md">
        <SearchBar value={search} onChange={setSearch} placeholder="Cari pelanggan atau proyek..." />
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm whitespace-nowrap">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 font-semibold text-gray-600">Pelanggan</th>
                <th className="px-6 py-4 font-semibold text-gray-600">Proyek</th>
                <th className="px-6 py-4 font-semibold text-gray-600 text-center">Jml Invoice</th>
                <th className="px-6 py-4 font-semibold text-gray-600 text-right">Total Tagihan</th>
                <th className="px-6 py-4 font-semibold text-gray-600 text-right">Telah Dibayar</th>
                <th className="px-6 py-4 font-semibold text-gray-600 text-right">Sisa Piutang</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {receivables.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-8 text-center text-gray-400 italic">
                    Tidak ada data piutang ditemukan.
                  </td>
                </tr>
              ) : (
                receivables.map((row) => (
                  <tr key={row.key} className="hover:bg-gray-50/50">
                    <td className="px-6 py-4 font-medium text-gray-900">{row.customerName}</td>
                    <td className="px-6 py-4 text-gray-600">
                      {row.projectId ? row.projectName : <span className="text-gray-400 italic">—</span>}
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className="inline-flex items-center justify-center w-6 h-6 rounded-full bg-blue-50 text-blue-600 font-medium text-xs">
                        {row.invoiceCount}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right text-gray-600">{formatRupiah(row.totalInvoice)}</td>
                    <td className="px-6 py-4 text-right text-emerald-600">{formatRupiah(row.totalPaid)}</td>
                    <td className="px-6 py-4 text-right font-bold text-red-600">
                      {formatRupiah(row.totalRemaining)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {receivables.length > 0 && (
              <tfoot className="bg-gray-50 border-t border-gray-200 font-bold">
                <tr>
                  <td colSpan={3} className="px-6 py-4 text-right text-gray-600">TOTAL KESELURUHAN</td>
                  <td className="px-6 py-4 text-right text-gray-900">{formatRupiah(grandTotalInvoice)}</td>
                  <td className="px-6 py-4 text-right text-emerald-600">
                    {formatRupiah(grandTotalInvoice - grandTotalRemaining)}
                  </td>
                  <td className="px-6 py-4 text-right text-red-600">{formatRupiah(grandTotalRemaining)}</td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      <ReceivablesPrintLayout ref={printRef} data={receivables} />
    </div>
  );
}
