import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/layout/Layout'
import Dashboard from './pages/Dashboard'
import MarketingPage from './pages/MarketingPage'
import CustomerPage from './pages/CustomerPage'
import InventoryPage from './pages/InventoryPage'
import SuratJalanPage from './pages/SuratJalanPage'
import InvoicePage from './pages/InvoicePage'
import SettingsPage from './pages/SettingsPage'
import RentalRecapPage from './pages/RentalRecapPage'
import ReportsPage from './pages/ReportsPage'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Dashboard />} />
          <Route path="marketing" element={<MarketingPage />} />
          <Route path="customers" element={<CustomerPage />} />
          <Route path="inventory" element={<InventoryPage />} />
          <Route path="surat-jalan" element={<SuratJalanPage />} />
          <Route path="invoice" element={<InvoicePage />} />
          <Route path="rekapan" element={<RentalRecapPage />} />
          <Route path="reports" element={<ReportsPage />} />
          <Route path="settings" element={<SettingsPage />} />
          <Route path="*" element={
            <div className="flex flex-col items-center justify-center h-[60vh]">
              <h2 className="text-2xl font-bold text-gray-700">Modul Belum Tersedia</h2>
              <p className="text-gray-400 mt-2">Halaman ini sedang dalam pengembangan.</p>
            </div>
          } />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App
