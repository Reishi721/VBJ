import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import { Card } from "../ui";

const data = [
  { name: "Tersedia", value: 1250, color: "#10b981", lightColor: "#d1fae5" },
  { name: "Disewa", value: 850, color: "#3b82f6", lightColor: "#dbeafe" },
  { name: "Maintenance", value: 120, color: "#f59e0b", lightColor: "#fef3c7" },
  { name: "Hilang/Rusak", value: 30, color: "#ef4444", lightColor: "#fee2e2" },
];

const total = data.reduce((sum, d) => sum + d.value, 0);

export default function AssetStatusChart() {
  return (
    <Card className="flex flex-col h-full">
      <div className="p-5 pb-0 shrink-0">
        <h3 className="text-[15px] font-bold text-gray-900">Status Aset</h3>
        <p className="text-[12px] text-gray-400 mt-0.5">Distribusi kondisi inventaris</p>
      </div>
      <div className="flex-1 flex flex-col items-center justify-center p-5 pt-2">
        <div className="relative w-full" style={{ height: 200 }}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                innerRadius={55}
                outerRadius={80}
                paddingAngle={3}
                dataKey="value"
                strokeWidth={0}
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value: number) => [`${value.toLocaleString('id-ID')} Unit`, ""]}
                contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 20px rgba(0,0,0,0.1)', fontSize: '12px' }}
              />
            </PieChart>
          </ResponsiveContainer>
          {/* Center text */}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <p className="text-2xl font-bold text-gray-900">{total.toLocaleString('id-ID')}</p>
            <p className="text-[10px] text-gray-400 font-medium">Total Unit</p>
          </div>
        </div>
        
        {/* Legend */}
        <div className="grid grid-cols-2 gap-2 w-full mt-2">
          {data.map((item) => (
            <div key={item.name} className="flex items-center gap-2 px-3 py-2 rounded-lg bg-gray-50/80">
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }} />
              <div className="flex-1 min-w-0">
                <p className="text-[11px] text-gray-500 truncate">{item.name}</p>
              </div>
              <p className="text-[11px] font-bold text-gray-700">{item.value.toLocaleString('id-ID')}</p>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}
