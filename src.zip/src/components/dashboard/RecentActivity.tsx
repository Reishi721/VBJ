import { formatDate } from "../../lib/utils";
import { ArrowUpRight } from "lucide-react";
import { Card, StatusBadge, Button } from "../ui";

const activities = [
  { id: "INV-2403-001", customer: "PT Pembangunan Jaya", project: "Proyek Mall Sudirman", status: "aktif", date: "2026-04-15", amount: 15000000 },
  { id: "INV-2403-002", customer: "CV Makmur Abadi", project: "Gedung Perkantoran BSD", status: "pending", date: "2026-04-16", amount: 8500000 },
  { id: "INV-2403-003", customer: "Bpk. Budi Santoso", project: "Renovasi Rumah", status: "selesai", date: "2026-04-10", amount: 3200000 },
  { id: "INV-2403-004", customer: "PT Konstruksi Utama", project: "Jembatan Tol Cikampek", status: "terlambat", date: "2026-04-01", amount: 24000000 },
  { id: "INV-2403-005", customer: "CV Indah Karya", project: "Apartemen Green Lake", status: "aktif", date: "2026-04-18", amount: 11500000 },
];

export default function RecentActivity() {
  return (
    <Card className="col-span-1 md:col-span-2 overflow-hidden flex flex-col">
      <div className="p-5 pb-4 flex items-center justify-between shrink-0">
        <div>
          <h3 className="text-[15px] font-bold text-gray-900">Aktivitas Terbaru</h3>
          <p className="text-[12px] text-gray-400 mt-0.5">5 transaksi rental terakhir</p>
        </div>
        <Button variant="ghost" size="sm" rightIcon={ArrowUpRight} className="text-blue-600 hover:text-blue-700">
          Lihat Semua
        </Button>
      </div>
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-t border-gray-100 bg-gray-50/50">
              <th className="px-5 py-3 text-left text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Invoice</th>
              <th className="px-5 py-3 text-left text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Pelanggan</th>
              <th className="px-5 py-3 text-left text-[11px] font-semibold text-gray-400 uppercase tracking-wider hidden lg:table-cell">Proyek</th>
              <th className="px-5 py-3 text-left text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Tanggal</th>
              <th className="px-5 py-3 text-left text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Status</th>
              <th className="px-5 py-3 text-right text-[11px] font-semibold text-gray-400 uppercase tracking-wider">Nilai</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {activities.map((activity) => (
              <tr key={activity.id} className="hover:bg-gray-50 transition-colors cursor-pointer group">
                <td className="px-5 py-3.5">
                  <span className="text-[13px] font-semibold text-gray-900">{activity.id}</span>
                </td>
                <td className="px-5 py-3.5">
                  <span className="text-[13px] text-gray-600">{activity.customer}</span>
                </td>
                <td className="px-5 py-3.5 hidden lg:table-cell">
                  <span className="text-[12px] text-gray-400">{activity.project}</span>
                </td>
                <td className="px-5 py-3.5">
                  <span className="text-[12px] text-gray-400">{formatDate(activity.date)}</span>
                </td>
                <td className="px-5 py-3.5">
                  <StatusBadge status={activity.status} />
                </td>
                <td className="px-5 py-3.5 text-right">
                  <span className="text-[13px] font-bold text-gray-900">
                    Rp {activity.amount.toLocaleString('id-ID')}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}
