import { AlertTriangle, Clock, ArrowUpRight } from "lucide-react";
import { Card, Button, Badge } from "../ui";

const dueItems = [
  { id: "INV-2402-089", customer: "PT Bangun Persada", project: "Proyek Jalan Tol", items: 150, daysOverdue: 0 },
  { id: "INV-2403-012", customer: "CV Mandiri Jaya", project: "Renovasi Kantor", items: 45, daysOverdue: 0 },
  { id: "INV-2403-018", customer: "PT Maju Bersama", project: "Gudang Cikarang", items: 80, daysOverdue: 2 },
];

export default function DueTodayWidget() {
  return (
    <Card className="col-span-1 flex flex-col h-full">
      <div className="p-5 pb-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <div>
            <h3 className="text-[15px] font-bold text-gray-900">Jatuh Tempo</h3>
            <p className="text-[12px] text-gray-400 -mt-0.5">Perlu tindakan segera</p>
          </div>
        </div>
        <span className="flex items-center justify-center w-7 h-7 rounded-full bg-amber-50 text-amber-600 text-[12px] font-bold">
          {dueItems.length}
        </span>
      </div>
      
      <div className="flex-1 px-2 overflow-y-auto">
        <div className="space-y-1">
          {dueItems.map((item) => (
            <div key={item.id} className="group p-3 rounded-xl hover:bg-gray-50 transition-all cursor-pointer">
              <div className="flex justify-between items-start">
                <div className="min-w-0 flex-1">
                  <p className="text-[13px] font-semibold text-gray-900 truncate">{item.customer}</p>
                  <p className="text-[11px] text-gray-400 truncate mt-0.5">{item.project}</p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <span className="inline-flex items-center gap-1 text-[10px] text-gray-400 font-medium">
                      <Clock className="w-3 h-3" />{item.id}
                    </span>
                    {item.daysOverdue > 0 && (
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded bg-red-50 text-[10px] font-semibold text-red-600">
                        +{item.daysOverdue} hari
                      </span>
                    )}
                  </div>
                </div>
                <div className="ml-3 flex flex-col items-end gap-1">
                  <Badge variant="amber">{item.items} Unit</Badge>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      
      <div className="p-4 border-t border-gray-100 shrink-0">
        <Button variant="secondary" fullWidth rightIcon={ArrowUpRight} className="text-gray-600">
          Lihat Semua Jatuh Tempo
        </Button>
      </div>
    </Card>
  );
}
