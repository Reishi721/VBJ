import { Link, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  Users, 
  Truck,
  Package, 
  ClipboardList,
  DollarSign, 
  BarChart3, 
  Settings,
  ChevronRight,
  Blocks,
  UserCheck,
  FileText
} from "lucide-react";
import { cn } from "../../lib/utils";

const navItems = [
  { name: "Dashboard",      href: "/",            icon: LayoutDashboard, group: "main" },
  { name: "Pelanggan",      href: "/customers",   icon: Users,           group: "main" },
  { name: "Marketing",      href: "/marketing",   icon: UserCheck,       group: "main" },
  { name: "Surat Jalan",    href: "/surat-jalan", icon: Truck,          group: "operations" },
  { name: "Inventaris",     href: "/inventory",   icon: Package,        group: "operations" },
  { name: "Rekapan Penyewa",href: "/rekapan",     icon: ClipboardList,  group: "operations" },
  { name: "Invoice",        href: "/invoice",     icon: FileText,        group: "finance" },
  { name: "Keuangan",       href: "/finance",     icon: DollarSign,      group: "finance" },
  { name: "Laporan",        href: "/reports",     icon: BarChart3,       group: "finance" },
  { name: "Pengaturan",     href: "/settings",    icon: Settings,        group: "system" },
];

const groups = [
  { key: "main", label: "Data Master" },
  { key: "operations", label: "Operasional" },
  { key: "finance", label: "Keuangan & Laporan" },
  { key: "system", label: "Sistem" },
];

export default function Sidebar() {
  const location = useLocation();

  return (
    <aside className="w-[260px] gradient-sidebar hidden md:flex md:flex-col relative overflow-hidden">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-40 h-40 bg-blue-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
      
      {/* Logo */}
      <div className="h-[72px] flex items-center px-6 border-b border-white/[0.08] relative z-10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 gradient-primary rounded-lg flex items-center justify-center shadow-lg shadow-blue-500/25">
            <Blocks size={20} className="text-white" />
          </div>
          <div>
            <span className="text-white font-bold text-[15px] tracking-tight">ScaffoldPro</span>
            <p className="text-[11px] text-slate-400 font-medium -mt-0.5">ERP System</p>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <div className="flex-1 overflow-y-auto py-4 sidebar-scroll relative z-10">
        <nav className="px-3 space-y-4">
          {groups.map((group) => {
            const items = navItems.filter((item) => item.group === group.key);
            return (
              <div key={group.key}>
                <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-[0.15em] px-3 mb-1.5">{group.label}</p>
                <div className="space-y-0.5">
                  {items.map((item) => {
                    const isActive = location.pathname === item.href;
                    return (
                      <Link
                        key={item.name}
                        to={item.href}
                        className={cn(
                          "group flex items-center gap-3 px-3 py-2.5 rounded-lg text-[13px] font-medium transition-all duration-200 relative",
                          isActive 
                            ? "bg-blue-500/15 text-blue-400" 
                            : "text-slate-400 hover:bg-white/[0.05] hover:text-slate-200"
                        )}
                      >
                        {isActive && (
                          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-5 bg-blue-400 rounded-r-full" />
                        )}
                        <item.icon className={cn(
                          "w-[18px] h-[18px] transition-colors shrink-0", 
                          isActive ? "text-blue-400" : "text-slate-500 group-hover:text-slate-300"
                        )} />
                        <span className="flex-1">{item.name}</span>
                        {isActive && <ChevronRight className="w-3.5 h-3.5 text-blue-400/60" />}
                      </Link>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </nav>
      </div>

      {/* Bottom section */}
      <div className="p-4 border-t border-white/[0.06] relative z-10">
        <div className="rounded-lg bg-gradient-to-br from-blue-500/20 to-purple-500/20 border border-white/[0.08] p-3">
          <p className="text-[11px] font-semibold text-white mb-0.5">Butuh bantuan?</p>
          <p className="text-[10px] text-slate-400 leading-relaxed">Hubungi support untuk bantuan teknis</p>
          <button className="mt-2 text-[11px] font-semibold text-blue-400 hover:text-blue-300 transition-colors">
            Hubungi Support →
          </button>
        </div>
      </div>
    </aside>
  );
}
