import { Bell, Search, CalendarDays, User } from "lucide-react";
import { useLocation } from "react-router-dom";
import { SearchBar } from "../ui";
export default function Header() {
  const location = useLocation();
  
  const getPageTitle = () => {
    const path = location.pathname;
    if (path === "/") return "Dashboard";
    if (path.includes("customers")) return "Pelanggan";
    if (path.includes("agreements")) return "Perjanjian Sewa";
    if (path.includes("inventory")) return "Inventaris";
    if (path.includes("returns")) return "Pengembalian";
    if (path.includes("finance")) return "Keuangan";
    if (path.includes("reports")) return "Laporan";
    if (path.includes("settings")) return "Pengaturan";
    return "Halaman";
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Selamat Pagi";
    if (hour < 17) return "Selamat Siang";
    return "Selamat Malam";
  };

  const today = new Date().toLocaleDateString("id-ID", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <header className="h-[72px] bg-white/70 backdrop-blur-xl border-b border-gray-200/60 flex items-center justify-between px-6 z-10 sticky top-0">
      <div className="flex flex-col">
        <h1 className="text-lg font-bold text-gray-900 tracking-tight">{getPageTitle()}</h1>
        <p className="text-[12px] text-gray-400 font-medium -mt-0.5">{getGreeting()} 👋 — {today}</p>
      </div>
      
      <div className="flex items-center gap-3">
        {/* Search */}
        <div className="hidden lg:block w-64">
          <SearchBar
            value=""
            onChange={() => {}}
            placeholder="Cari data..."
            containerClassName="w-full"
            className="bg-gray-100/80 border-0 focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:shadow-lg focus:shadow-blue-500/5"
          />
        </div>

        {/* Date badge */}
        <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gray-100/80 text-xs text-gray-500 font-medium">
          <CalendarDays className="w-3.5 h-3.5" />
          {new Date().toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" })}
        </div>
        
        {/* Notification */}
        <button className="relative p-2.5 text-gray-400 hover:text-gray-600 rounded-xl hover:bg-gray-100/80 transition-all duration-200">
          <span className="absolute top-2 right-2 block h-2 w-2 rounded-full bg-red-500 ring-2 ring-white animate-pulse" />
          <Bell className="w-[18px] h-[18px]" />
        </button>

        {/* Divider */}
        <div className="h-8 w-px bg-gray-200" />
        
        {/* User */}
        <button className="flex items-center gap-2.5 px-2 py-1.5 rounded-xl hover:bg-gray-100/80 transition-all duration-200">
          <div className="h-8 w-8 rounded-lg gradient-primary flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <User className="w-4 h-4" />
          </div>
          <div className="hidden md:block text-left">
            <p className="text-[12px] font-semibold text-gray-800">Admin</p>
            <p className="text-[10px] text-gray-400 -mt-0.5">Main Office</p>
          </div>
        </button>
      </div>
    </header>
  );
}
